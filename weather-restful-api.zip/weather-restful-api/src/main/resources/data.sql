/*INSERT INTO 
	WEATHER_INFO (api_url, api_key, city, country, request, response) 
VALUES
  	('http://localhost:8080/London/uk', '7257d8782a5eb0a6fa450c5c3a8884a1', 'London', 'uk', 'http://localhost:8080/London/uk', '{"timestamp": "2021-06-15T01:37:57.302+0000","status": 404,"error": "Not Found","message": "No message available","path": "/London/uk"}');
*/