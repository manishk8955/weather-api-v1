package com.weather.api.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.weather.api.model.WeatherEntity;
import com.weather.api.model.response.WeatherResponse;
import com.weather.api.rest.service.WeatherService;
import com.weather.api.validation.RequestValidator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController
public class WeatherController {
	@Autowired
	WeatherService service;
	
	@Autowired
	RequestValidator requestValidator;
	
	public WeatherController(WeatherService service, RequestValidator requestValidator) {
		super();
		this.service = service;
		this.requestValidator = requestValidator;
	}

	@GetMapping("/weather-restful-api/{city}/{country}")
	public ResponseEntity<Object> getWeatherForecastCityCountry(@PathVariable String city, @PathVariable String country,
			@RequestHeader HttpHeaders headers) {
		String apiKey = StringUtils.EMPTY;
		log.info("*** Getting Weather forecast for city :: {}", city + " country :: {}" + country);

		apiKey = requestValidator.getApiKeyHeaders(headers, apiKey);
		
		requestValidator.validateRequestInputs(country, city, apiKey);		
		log.debug("city - {}", city);
		log.debug("country - {}", country);
		log.debug("apiKey - {}", apiKey);
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCity(city);
		weatherEntity.setCountry(country);
		weatherEntity.setApiKey(apiKey);		
        
		requestValidator.isValidApiKey(weatherEntity);

		WeatherResponse weatherResponse = service.getWeatherForecastCityCountry(weatherEntity);
		
		log.info("*** Weather forecast :: {}", weatherResponse);
		return ResponseEntity.ok().body(weatherResponse);
	}

}
