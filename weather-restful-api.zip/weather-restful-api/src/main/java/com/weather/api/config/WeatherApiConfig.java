package com.weather.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.weather.api.validation.RequestValidator;

@Configuration
public class WeatherApiConfig {

    @Bean
    public RestTemplate getRestTemplate() {
        return new RestTemplate();
    }
    
    @Bean
    public RequestValidator getRequestValidator() {
        return new RequestValidator();
    }

}
