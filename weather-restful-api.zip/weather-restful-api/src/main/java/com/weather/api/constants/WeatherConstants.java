package com.weather.api.constants;
public class WeatherConstants {
	public static String VALIDATION_CITY = "City field should not be null or empty";
	public static String VALIDATION_COUNTRY = "Country field should not be null or empty";
	public static String VALIDATION_API_KEY = "ApiKey field should not be null or empty";
    public static String WEATHER_RECORD_NOT_FOUND="Weather forecast not found for provided City and Country";
	public static String INVALID_API_KEY = "Invalid API Key";
	public static String WEATHER_API_URL="https://api.openweathermap.org/data/2.5/forecast?q={q}&appid={appid}";
}
