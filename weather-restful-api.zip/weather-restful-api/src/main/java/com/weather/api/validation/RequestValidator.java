package com.weather.api.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.weather.api.constants.WeatherConstants;
import com.weather.api.exception.handler.InvalidInputException;
import com.weather.api.exception.handler.WeatherForecastNotFoundException;
import com.weather.api.model.WeatherEntity;

@Component
public class RequestValidator {
	
	@Autowired
	Environment environment;

	public boolean validateRequestInputs(String country, String city, String apiKey) {

		if (StringUtils.isBlank(city)) {
			throw new InvalidInputException(WeatherConstants.VALIDATION_CITY);
		}

		if (StringUtils.isBlank(country)) {
			throw new InvalidInputException(WeatherConstants.VALIDATION_COUNTRY);
		}
		
		if (StringUtils.isBlank(apiKey)) {
			throw new InvalidInputException(WeatherConstants.VALIDATION_API_KEY);
		}

		return true;

	}
	
	public void isValidApiKey(WeatherEntity weatherEntity) {
		List<String> keyList = new ArrayList<>(Arrays.asList(getWeatherApiKeys()));
        if(keyList!=null && !keyList.contains(weatherEntity.getApiKey())) {
        	throw new WeatherForecastNotFoundException(WeatherConstants.INVALID_API_KEY);
        }
	}	
    
    public String[] getWeatherApiKeys() {
 	   return environment.getProperty("weather.api.key",String[].class);
    }
    
	public String getApiKeyHeaders(HttpHeaders headers, String apiKey) {
		if (headers.containsKey("x-api-key") && (headers.getValuesAsList("x-api-key").size()) > 0) {
			apiKey = (headers.getValuesAsList("x-api-key")).get(0);
		}
		return apiKey;
	}
}
