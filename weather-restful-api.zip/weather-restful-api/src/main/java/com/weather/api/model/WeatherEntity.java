package com.weather.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name="WEATHER_INFO")
public class WeatherEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
	@Column(name = "city")
	private String city;

	@Column(name = "country")
	private String country;
    
    @Column(name="api_key")
    private String apiKey;
    
    @Column(name="response")
    private String response;

    public String toString() {
		return "WeatherEntity [id=" + id + ", city=" + city + ", country=" + country
				+ ", apiKey=" + apiKey + ", response=" + response + "]";
	}
    
	public WeatherEntity(Long id, String apiKey, String response) {
		super();
		this.id = id;
		this.apiKey = apiKey;
		this.response = response;
	}
	
	public WeatherEntity(String apiKey, String response) {
		super();
		this.apiKey = apiKey;
		this.response = response;
	}
	
    public WeatherEntity(Long id, String city, String country, String apiKey, 
			String response) {
		super();
		this.id = id;
		this.city = city;
		this.country = country;
		this.apiKey = apiKey;
		this.response = response;
	}

	public WeatherEntity(String city, String country, String apiKey, String response) {
		super();
		this.city = city;
		this.country = country;
		this.apiKey = apiKey;
		this.response = response;
	}
}