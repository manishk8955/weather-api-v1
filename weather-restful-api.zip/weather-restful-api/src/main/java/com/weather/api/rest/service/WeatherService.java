package com.weather.api.rest.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.weather.api.model.ListData;
import com.weather.api.model.WeatherEntity;
import com.weather.api.model.WeatherRoot;
import com.weather.api.model.response.WeatherResponse;
import com.weather.api.rest.client.WeatherRestClient;
import com.weather.api.rest.repository.WeatherRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
public class WeatherService {
	@Autowired
	Environment environment;
	
	@Autowired
	WeatherRestClient restClient;
	
	@Autowired
	WeatherRepository repository;	

	public WeatherService(WeatherRestClient restClient, WeatherRepository repository) {
		this.restClient = restClient;
		this.repository = repository;
	}
	
    public WeatherResponse getWeatherForecastCityCountry(WeatherEntity weatherEntity) {
        WeatherRoot response;
        WeatherResponse weatherResponse;
        log.info("*** Getting Weather forecast for  city :: {}", weatherEntity.getCity() + " country :: {}" +weatherEntity.getCountry());        
        
		Optional<WeatherEntity> weather = repository.findByCityAndCountry(weatherEntity.getCity(),weatherEntity.getCountry());
		
		if(weather.isPresent()) {			
			WeatherEntity entity = weather.get();
			log.info("Search data found in Database - {} ",entity.toString());
			
			weatherResponse = WeatherResponse.builder()
	                .cityName(entity.getCity())
	                .country(entity.getCountry())
	                .response(entity.getResponse())	                    
	                .build();
		}
		else {
			//Invoke OpenWeatherMap API
			response = restClient.invokeWeatherRestApi(weatherEntity);
			
			weatherResponse = WeatherResponse.builder()
	                .cityName(response.getCity().getName())
	                .country(response.getCity().getCountry())
	                .tomorrowsForecast(getTomorrowsPredictedData(response.getList()))     
	                .build();
			weatherEntity.setResponse(weatherResponse.toString());
			WeatherEntity entity = repository.saveAndFlush(weatherEntity);
			log.info("Search Data unavailable. Invoking OpenWeatherMap API and persting the response in DB - {} ",entity);
			
			log.info("*** Weather forecast :: {}", weatherResponse);
		}
        return weatherResponse;
	}

    
    private Map<String, Double> getTomorrowsPredictedData(List<ListData> list) {
        log.info("*** Populating Weather forecast for tomorrow");
        Map<String, Double> hourlyTemperature = new HashMap<>();
        LocalDate tomorrowsLocalDate = LocalDate.now().plusDays(1);
        list.forEach(listData -> {
                    LocalDate forecastedDate = Instant.ofEpochMilli(new Date(listData.getDt() * 1000)
                            .getTime())
                            .atZone(ZoneId.systemDefault())
                            .toLocalDate();

                    if (tomorrowsLocalDate.getDayOfMonth() == forecastedDate.getDayOfMonth()) {
                        hourlyTemperature.put(listData.getDt_txt(), listData.getMain().getTemp_min());
                    }
                }
        );
        log.info("*** Populated Weather forecast for tomorrow");
        return hourlyTemperature;
    }

}
