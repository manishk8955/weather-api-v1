package com.weather.api.rest.client;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.weather.api.constants.WeatherConstants;
import com.weather.api.exception.handler.WeatherForecastNotFoundException;
import com.weather.api.model.WeatherEntity;
import com.weather.api.model.WeatherRoot;
import lombok.extern.slf4j.Slf4j;

/**
 * Make a REST API call to OpenWeatherMap
 * 
 * @author manish
 *
 */
@Component
@Slf4j
public class WeatherRestClient {
	@Autowired
	Environment environment;

	private final RestTemplate restTemplate = new RestTemplate();

	/**
	 * Method to call the OpenWeatherMap API 
	 * @param weatherEntity 
	 * @return WeatherRoot
	 */
	public WeatherRoot invokeWeatherRestApi(WeatherEntity weatherEntity) {
		String apiUrl = (null != environment) ? environment.getProperty("weather.api.url")
				: WeatherConstants.WEATHER_API_URL;
		WeatherRoot response = new WeatherRoot();

		Map<String, String> params = constructRequestParams(weatherEntity);

		try {
			response = restTemplate.getForObject(apiUrl, WeatherRoot.class, params);
			log.info("*** Weather forecast for provided city and country :: {}", response);

		} catch (Exception e) {
			throw new WeatherForecastNotFoundException(WeatherConstants.WEATHER_RECORD_NOT_FOUND);
		}

		return response;
	}

	/**
	 * Build the Request Parameters for weather entity 
	 * @param weatherEntity 
	 * @return Params Map
	 */
	private Map<String, String> constructRequestParams(WeatherEntity weatherEntity) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("q", constructCityCountryParam(weatherEntity.getCity(), weatherEntity.getCountry()));
		params.put("appid", weatherEntity.getApiKey());
		return params;
	}

	private String constructCityCountryParam(String city, String country) {
		StringBuilder strbuilder = new StringBuilder().append(city).append(",").append(country);
		return strbuilder.toString();
	}

}
