package com.weather.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.weather.api.WeatherApiApplication;

@SpringBootTest(classes = WeatherApiApplication.class)
class WeatherApplicationApiTests {

	@Test
	void contextLoads() {
	}

}
