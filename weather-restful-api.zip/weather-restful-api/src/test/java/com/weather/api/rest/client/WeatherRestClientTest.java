package com.weather.api.rest.client;


import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import com.weather.api.constants.WeatherConstants;
import com.weather.api.model.City;
import com.weather.api.model.ListData;
import com.weather.api.model.Main;
import com.weather.api.model.WeatherEntity;
import com.weather.api.model.WeatherRoot;
import com.weather.api.rest.client.WeatherRestClient;

/**
 * @author manish
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class WeatherRestClientTest {
	
	@Mock
	RestTemplate restTemplate = mock(RestTemplate.class);
	
	@Mock
	Environment environment = mock(Environment.class);
	
	WeatherRestClient restClient = new WeatherRestClient();
	
	@Test
	public void testWeatherRestApiCall() {
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("UK");
		weatherEntity.setCity("London");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");
		
		Map<String, String> params = constructRequestParams(weatherEntity);		
		when(restTemplate.getForObject(WeatherConstants.WEATHER_API_URL, WeatherRoot.class, params)).thenReturn(getWeatherRoot());

		WeatherRoot response = restClient.invokeWeatherRestApi(weatherEntity);
		assertNotNull(response);	
	}
	
	public WeatherRoot getWeatherRoot() {
		WeatherRoot weatherRoot = new WeatherRoot();
		List<ListData> dataList = new ArrayList<>();
		ListData data = new ListData();
		data.setDt(1605344400000L);
		data.setDt_txt("2020-11-14 09:00:00");
		Main main = new Main();
		main.setTemp_min(280.39);
		data.setMain(main);
		dataList.add(data);
		weatherRoot.setList(dataList);
		City city = new City();
		city.setCountry("uk");
		city.setName("London");
		weatherRoot.setCity(city);
		return weatherRoot;
	}
	
	public Map<String, String> constructRequestParams(WeatherEntity weatherEntity) {
		Map<String, String> params = new HashMap<String, String>();
        params.put("q", constructCityCountryParam(weatherEntity.getCity(),weatherEntity.getCountry()));
        params.put("appid", weatherEntity.getApiKey());
		return params;
	}
	
    public String constructCityCountryParam(String city, String country) {
    	StringBuilder strbuilder=new StringBuilder().append(city).append(",").append(country);
    	return strbuilder.toString();    	
    }

}
