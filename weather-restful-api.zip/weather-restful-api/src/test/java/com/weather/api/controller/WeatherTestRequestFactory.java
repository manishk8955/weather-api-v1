package com.weather.api.controller;

import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

public class WeatherTestRequestFactory {
	public static MockHttpServletRequestBuilder factoryRequest(String url) {
        return MockMvcRequestBuilders.get(url)
                .header("x-api-key", "612c7259174856294ac2bd0efb5dbdb2");
    }
	
	public static MockHttpServletRequestBuilder invalidApiKeyFactoryRequest(String url) {
        return MockMvcRequestBuilders.get(url)
                .header("x-api-key", "612c7259174856");
    }
	
	public static MockHttpServletRequestBuilder missingApiKeyFactoryRequest(String url) {
        return MockMvcRequestBuilders.get(url)
                .header("x-api-key", "");
    }
}
