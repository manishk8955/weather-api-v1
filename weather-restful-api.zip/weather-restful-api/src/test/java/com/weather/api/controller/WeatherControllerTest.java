package com.weather.api.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.web.servlet.MockMvc;

import com.weather.api.constants.WeatherConstants;
import com.weather.api.model.WeatherEntity;
import com.weather.api.model.response.WeatherResponse;
import com.weather.api.rest.service.WeatherService;


@WebMvcTest
@ComponentScan(basePackages = "com.weather.api")
public class WeatherControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private WeatherService weatherService;
	
	private static final String VALID_URL = "/weather-restful-api/London/uk";
	private static final String INVALID_URL = "/weather-restful-api/London"; 
	private static final String INVALID_API_KEY = "/weather-restful-api/London/uk";
	private static final String INVALID_URL_CITY = "/weather-restful-api/London123/uk";
	private static final String MISSING_API_KEY = "/weather-restful-api/London/uk";


	@Test
	public void testGetWeatherCityCountryService() throws Exception {
		WeatherResponse weatherAPIResponse = WeatherResponse.builder().build();
		weatherAPIResponse.setCityName("London");		
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");

		Mockito.when(weatherService.getWeatherForecastCityCountry(weatherEntity)).thenReturn(weatherAPIResponse);
		
		mockMvc.perform(WeatherTestRequestFactory.factoryRequest(VALID_URL))
        .andExpect(status().isOk());

	}

	@Test
	public void testGetWeatherCityCountryService_isNotFound() throws Exception {

		WeatherResponse weatherAPIResponse = WeatherResponse.builder().build();
		weatherAPIResponse.setCityName("London");		
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");

		Mockito.when(weatherService.getWeatherForecastCityCountry(weatherEntity)).thenReturn(weatherAPIResponse);
		
		mockMvc.perform(WeatherTestRequestFactory.factoryRequest(INVALID_URL))
        .andExpect(status().isNotFound());

	}
	
	@Test
	public void testGetWeatherCityCountryService_isUnauthorized() throws Exception {

		WeatherResponse weatherAPIResponse = WeatherResponse.builder().build();
		weatherAPIResponse.setCityName("London");		
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London");
		weatherEntity.setApiKey("612c7259174856");

		Mockito.when(weatherService.getWeatherForecastCityCountry(weatherEntity)).thenReturn(weatherAPIResponse);

		mockMvc.perform(WeatherTestRequestFactory.invalidApiKeyFactoryRequest(INVALID_API_KEY))
        .andExpect(status().isNotFound())
        .andExpect(jsonPath("message", Matchers.equalTo("Invalid API Key")));

	}
	
	@Test
	public void testGetWeatherCityCountryService_noApiKey() throws Exception {
		WeatherResponse weatherAPIResponse = WeatherResponse.builder().build();
		weatherAPIResponse.setCityName("London");
		weatherAPIResponse.setCountry("uk");
		
		mockMvc.perform(WeatherTestRequestFactory.missingApiKeyFactoryRequest(MISSING_API_KEY))
        .andExpect(status().isBadRequest())
        .andExpect(jsonPath("message", Matchers.equalTo(WeatherConstants.VALIDATION_API_KEY)));

	}
	
	@Test
	public void testGetWeatherCityCountryService_invalidCity() throws Exception {		
		WeatherResponse weatherAPIResponse = WeatherResponse.builder().build();
		weatherAPIResponse.setResponse(WeatherConstants.WEATHER_RECORD_NOT_FOUND);
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London123");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");		
		mockMvc.perform(WeatherTestRequestFactory.factoryRequest(INVALID_URL_CITY));
	}	
	
	
}
