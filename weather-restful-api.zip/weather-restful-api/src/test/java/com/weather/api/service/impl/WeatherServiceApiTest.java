package com.weather.api.service.impl;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import com.weather.api.constants.WeatherConstants;
import com.weather.api.exception.handler.WeatherForecastNotFoundException;
import com.weather.api.model.City;
import com.weather.api.model.ListData;
import com.weather.api.model.Main;
import com.weather.api.model.WeatherEntity;
import com.weather.api.model.WeatherRoot;
import com.weather.api.model.response.WeatherResponse;
import com.weather.api.rest.client.WeatherRestClient;
import com.weather.api.rest.repository.WeatherRepository;
import com.weather.api.rest.service.WeatherService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class WeatherServiceApiTest {

	@InjectMocks
	private WeatherService service;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	WeatherRepository repository;

	@Mock
	WeatherRestClient restClient;

	@Mock
	private Environment environment;

	@Test(expected = WeatherForecastNotFoundException.class)
	public void getWeatherForecastFailureTest() {
		when(this.environment.getProperty("weather.api.url"))
				.thenReturn("https://api.openweathermap.org/data/2.5/forecast?q={q}&appid={appid}");
		String apiUrl = "https://api.openweathermap.org/data/2.5/forecast?q=London,uk&appid=7257d8782a5eb0a6fa450c5c3a8884a1";
		WeatherRoot weatherRoot = new WeatherRoot();
		City city = new City();
		city.setCountry("uk");
		city.setName("London12");
		weatherRoot.setCity(city);
		List<ListData> dataList = new ArrayList<>();
		ListData data = new ListData();
		data.setDt(1605344400000L);
		data.setDt_txt("2020-11-14 09:00:00");
		Main main = new Main();
		main.setTemp_min(280.39);
		data.setMain(main);
		dataList.add(data);
		weatherRoot.setList(dataList);

		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London12");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");

		when(restClient.invokeWeatherRestApi(getWeatherEntity())).thenReturn(weatherRoot);
		when(restTemplate.getForObject(apiUrl, WeatherRoot.class)).thenReturn(weatherRoot);
		when(restClient.invokeWeatherRestApi(weatherEntity)).thenThrow(new WeatherForecastNotFoundException(WeatherConstants.WEATHER_RECORD_NOT_FOUND));

		WeatherResponse weatherResponse = service.getWeatherForecastCityCountry(weatherEntity);
	}

	@Test
	public void getWeatherForecastSuccessTest() {
		when(this.environment.getProperty("weather.api.url"))
				.thenReturn("https://api.openweathermap.org/data/2.5/forecast?q={q}&appid={appid}");

		String apiUrl = "https://api.openweathermap.org/data/2.5/forecast?q=London,uk&appid=7257d8782a5eb0a6fa450c5c3a8884a1";
		WeatherRoot weatherRoot = getWeatherRoot();

		when(restTemplate.getForObject(apiUrl, WeatherRoot.class)).thenReturn(weatherRoot);
		WeatherEntity entity = getWeatherEntity();
		Optional<WeatherEntity> optionalEntity = Optional.of(entity);

		when(repository.findByCityAndCountry(entity.getCity(), entity.getCountry())).thenReturn(optionalEntity);
		WeatherResponse response = service.getWeatherForecastCityCountry(getWeatherEntityObj());
		Assert.assertEquals("London", response.getCityName());

	}

	private WeatherEntity getWeatherEntity() {
		return new WeatherEntity("London", "uk", "7257d8782a5eb0a6fa450c5c3a8884a1", "Response");
	}

	private WeatherRoot getWeatherRoot() {
		WeatherRoot weatherRoot = new WeatherRoot();
		List<ListData> dataList = new ArrayList<>();
		ListData data = new ListData();
		data.setDt(1605344400000L);
		data.setDt_txt("2020-11-14 09:00:00");
		Main main = new Main();
		main.setTemp_min(280.39);
		data.setMain(main);
		dataList.add(data);
		weatherRoot.setList(dataList);
		City city = new City();
		city.setCountry("uk");
		city.setName("London");
		weatherRoot.setCity(city);
		return weatherRoot;
	}

	private WeatherEntity getWeatherEntityObj() {
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCity("London");
		weatherEntity.setCountry("uk");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");
		return weatherEntity;
	}
}
