/**
 * 
 */
package com.weather.api.service.impl;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.ComponentScan;

import com.weather.api.model.City;
import com.weather.api.model.ListData;
import com.weather.api.model.Main;
import com.weather.api.model.WeatherEntity;
import com.weather.api.model.WeatherRoot;
import com.weather.api.model.response.WeatherResponse;
import com.weather.api.rest.client.WeatherRestClient;
import com.weather.api.rest.repository.WeatherRepository;
import com.weather.api.rest.service.WeatherService;

@RunWith(MockitoJUnitRunner.Silent.class)
@ComponentScan(basePackages = "com.weather,com.weather.api")
public class WeatherServiceTest {
	
	WeatherRestClient restClient = mock(WeatherRestClient.class);
	
	WeatherRepository repository = mock(WeatherRepository.class);	
	
	WeatherService weatherService = new WeatherService(restClient,repository);
	
	@Test
	public void testWeatherService_restClient() {
		
		WeatherRoot weatherRoot = new WeatherRoot();
		City city= new City();
		city.setCountry("uk");
		city.setName("London");
		weatherRoot.setCity(city);
		List<ListData> dataList = new ArrayList<>();
		ListData data = new ListData();
		data.setDt(1605344400000L);
		data.setDt_txt("2020-11-14 09:00:00");
		Main main = new Main();
		main.setTemp_min(280.39);
		data.setMain(main);
		dataList.add(data);
		weatherRoot.setList(dataList);
		
		WeatherResponse response = WeatherResponse.builder().build();
		response.setCityName("London");
		response.setCountry("uk");
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");
		
		when(restClient.invokeWeatherRestApi(weatherEntity)).thenReturn(weatherRoot);
		
		WeatherResponse weatherResponse = weatherService.getWeatherForecastCityCountry(weatherEntity);
		
		assertEquals(weatherResponse.getCityName(), "London"); 
		
	}
	
	@Test
	public void testWeatherService_from_repository() {
		
		WeatherRoot weatherRoot = new WeatherRoot();
		City city= new City();
		city.setCountry("uk");
		city.setName("London");
		weatherRoot.setCity(city);
		List<ListData> dataList = new ArrayList<>();
		ListData data = new ListData();
		data.setDt(1605344400000L);
		data.setDt_txt("2020-11-14 09:00:00");
		Main main = new Main();
		main.setTemp_min(280.39);
		data.setMain(main);
		dataList.add(data);
		weatherRoot.setList(dataList);
		
		WeatherResponse response = WeatherResponse.builder().build();
		response.setCityName("London");
		response.setCountry("uk");
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");
		
		when(repository.findByCityAndCountry("London", "uk")).thenReturn(Optional.ofNullable(weatherEntity));
		
		WeatherResponse weatherResponse = weatherService.getWeatherForecastCityCountry(weatherEntity);
		
		assertEquals(weatherResponse.getCountry(), "uk"); 
		
	}
	
	@Test
	public void testWeatherService_failure() {
		
		WeatherRoot weatherRoot = new WeatherRoot();
		City city= new City();
		city.setCountry("uk");
		city.setName("London");
		weatherRoot.setCity(city);
		List<ListData> dataList = new ArrayList<>();
		ListData data = new ListData();
		data.setDt(1605344400000L);
		data.setDt_txt("2020-11-14 09:00:00");
		Main main = new Main();
		main.setTemp_min(280.39);
		data.setMain(main);
		dataList.add(data);
		weatherRoot.setList(dataList);
		
		WeatherResponse response = WeatherResponse.builder().build();
		response.setCityName("London");
		response.setCountry("uk");
		
		WeatherEntity weatherEntity = new WeatherEntity();
		weatherEntity.setCountry("uk");
		weatherEntity.setCity("London");
		weatherEntity.setApiKey("7257d8782a5eb0a6fa450c5c3a8884a1");
		
		when(restClient.invokeWeatherRestApi(weatherEntity)).thenReturn(weatherRoot);
		
		WeatherResponse weatherResponse = weatherService.getWeatherForecastCityCountry(weatherEntity);
		
		assertNotEquals(weatherResponse.getCityName(), "London12"); 
		
	}

}
